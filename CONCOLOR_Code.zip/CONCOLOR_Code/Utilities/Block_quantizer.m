function a=Block_quantizer(x,QTable)

% Jian Zhang

a=x./QTable;