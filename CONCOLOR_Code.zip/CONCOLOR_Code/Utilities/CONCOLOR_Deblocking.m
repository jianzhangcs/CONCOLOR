
function  [d_im, All_PSNR]  =  CONCOLOR_Deblocking(Inoi, par)

ori_im = par.I;
n_im = Inoi;
[h1 w1]     =   size(ori_im);

IterNum = par.IterNum;
d_im        =   Inoi;
lamada      =   0.04;
v           =   par.nSig;
cnt         =   1;

All_PSNR = zeros(1,IterNum);
Opts.ImgNoi = Inoi;

for i  =  1 : IterNum
    
    if (i ==1)
        d_im = n_im;
        nSig1  = v;
    end
    
    par.nSig = nSig1;
    par.IterNum = 6;
    %tic;
    [d_im]  =  CONCOLOR_Solver(d_im, par);
    %toc;
    
    dif1     =   d_im-n_im;
    vd1      =   v^2-(mean(mean(dif1.^2)));
    nSig1 = sqrt(abs(vd1))*par.lamada;
    
    d_im = (d_im*v^2*2 + n_im*nSig1^2)/(v^2*2 + nSig1^2);
    
    d_im = BDCT_project_onto_QCS(d_im, par.C_q, par.QTable, par.Qfactor, par.blockSize);
    
    PSNR        =   csnr( d_im(1:h1,1:w1), ori_im, 0, 0 );
    All_PSNR(cnt) = PSNR;
    
    fprintf( 'Preprocessing, Iter %d : PSNR = %2.2f\n', cnt, PSNR);
    cnt   =  cnt + 1;
end
