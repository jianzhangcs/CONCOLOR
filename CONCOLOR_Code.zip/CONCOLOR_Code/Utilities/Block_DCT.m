function [I_q, C_q]  = Block_DCT(I ,QTable, blockSize)

% Jian Zhang


I_q  = [];

if(isa(I , 'uint8'))
    I    = double(I );
end;

[height, width] = size(I);

if(mod(height, blockSize)~=0 | mod(width, blockSize) ~= 0)
    error('image dimension must be multiple of block of %d', blockSize);
end;

C       = blkproc(I , [blockSize blockSize], 'dct2');
C_qn    = blkproc(C, [blockSize blockSize], 'Block_quantizer', QTable);
C_qn    = round(C_qn);
C_q     = blkproc(C_qn, [blockSize blockSize], 'Block_dequantizer', QTable);

plot_flag1 = 0;
if plot_flag1
    C_d = C_q - C;
    for k = 1:8
        for j = 1:8
            C_d4 = C_d(k:8:end,j:8:end);
%             figure(100);hist(C_d4(:),100);
%             Final_Name = ['Boat 512 k=',num2str(k),' j=',num2str(j)];
%             title(['Boat 512 k=',num2str(k),' j=',num2str(j)]);
%             saveas(gcf,Final_Name,'png');
        end
    end
    
    
end



I_q     = blkproc(C_q, [blockSize blockSize], 'idct2');

plot_flag2 = 1;
if plot_flag2
    I_d = I_q - I;
    for k = 1:8
        for j = 1:8
            I_d4 = I_d(k:8:end,j:8:end);
%             figure(100);hist(I_d4(:),100);
%             Final_Name = ['Boat 512 k=',num2str(k),' j=',num2str(j)];
%             title(['Boat 512 k=',num2str(k),' j=',num2str(j)]);
%             saveas(gcf,Final_Name,'png');
        end
    end
    
    
end




