
function  [d_im]  =  CONCOLOR_Solver(Inoi, par)

n_im = Inoi;
[h1 w1]     =   size(Inoi);

IterNum = par.IterNum;
d_im        =   Inoi;
lamada      =   0.1;
v           =   par.nSig;
cnt         =   1;

Opts.ImgNoi = Inoi;

for i  =  1 : IterNum %
    
    d_im    =   d_im + lamada*(n_im - d_im);
    
    dif     =   d_im-n_im;
    vd      =   v^2-(mean(mean(dif.^2)));
    
    if (i ==1)
        par.nSig  = sqrt(abs(vd));
    end
    
    Opts.v = par.nSig;
    Opts.Iter = i;
    %tic
    if i == 1
        [d_im, IndcMatrix] = CONCOLOR_Solver_Prox(d_im, Opts);
    else
        [d_im] = CONCOLOR_Solver_Prox_index(d_im, Opts, IndcMatrix);
    end
    %toc
    
    cnt   =  cnt + 1;
end
