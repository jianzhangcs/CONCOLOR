function [ImgRec, IndcMatrix] = CONCOLOR_Solver_Prox(ImgInput, Opts)

if ~isfield(Opts,'PatchSize')
    Opts.PatchSize = 6;
end

SlidingDis   =  3;


if ~isfield(Opts,'ArrayNo')
    Opts.ArrayNo = 60;
end

if ~isfield(Opts,'SearchWin')
    Opts.SearchWin = 30;
end

ImgNoi = Opts.ImgNoi;

[Hight Width]   =   size(ImgInput);
SearchWin = Opts.SearchWin;
PatchSize    =    Opts.PatchSize;
PatchSize2    =   PatchSize*PatchSize;
ArrayNo   =   Opts.ArrayNo;
nSig = Opts.v;

N     =  Hight-PatchSize+1;
M     =  Width-PatchSize+1;
L     =  N*M;

Row     =  [1:SlidingDis:N];
Row     =  [Row Row(end)+1:N];
Col     =  [1:SlidingDis:M];
Col    =  [Col Col(end)+1:M];

PatchSet     =  zeros(PatchSize2, L, 'single');
PatchSet_Noi     =  zeros(PatchSize2, L, 'single');

Count     =  0;
for i  = 1:PatchSize
    for j  = 1:PatchSize
        Count    =  Count+1;
        Patch  =  ImgInput(i:Hight-PatchSize+i,j:Width-PatchSize+j);
        Patch  =  Patch(:);
        PatchSet(Count,:) =  Patch';
        
        Patch_Noi  =  ImgNoi(i:Hight-PatchSize+i,j:Width-PatchSize+j);
        Patch_Noi  =  Patch_Noi(:);
        PatchSet_Noi(Count,:) =  Patch_Noi';
        
        
    end
end

PatchSetT  =   PatchSet';


NewPatchSet = zeros(size(PatchSet));
NewWeight = zeros(size(PatchSet));

I        =   (1:L);
I        =   reshape(I, N, M);
NN       =   length(Row);
MM       =   length(Col);

ImgTemp     =  zeros(Hight, Width);
ImgWeight   =  zeros(Hight, Width);
PatchArray  =  zeros(PatchSize, PatchSize, ArrayNo);
IndcMatrix  =  zeros(NN, MM, ArrayNo);
%tic;


for  i  =  1 : NN
    for  j  =  1 : MM
        
        CurRow      =   Row(i);
        CurCol      =   Col(j);
        Off      =   (CurCol-1)*N + CurRow;
        
        CurPatchIndx  =  PatchSearch(PatchSetT, CurRow, CurCol, Off, ArrayNo, SearchWin, I);
        CurPatchIndx(1) = Off;
        IndcMatrix(i,j,:) = CurPatchIndx;
        
        CurArray = double(PatchSet(:, CurPatchIndx));
        
        
        if Opts.Iter == 1
            v = nSig;
        else
            CurArray_Noi = PatchSet_Noi(:, CurPatchIndx);
            
            v = 0.5*sqrt(abs(nSig^2 - mean((CurArray(:)-CurArray_Noi(:)).^2)));
            
        end
        
        [SG_S SG_V SG_D] = svd(CurArray,'econ');
        
        Temp = (diag(SG_V)).^0.8;
        
        for kk = 1:5
            W_Vec    =   (2.82*sqrt(60)*v^2)./( Temp + eps );               % Weight vector
            SigmaX   =  soft(SG_V, diag(W_Vec));
            Temp     = diag(SigmaX);
        end
        
        SG_Z     = SigmaX;
        
        CurArray = SG_S*SG_Z*SG_D';
        
        NewPatchSet(:, CurPatchIndx) = NewPatchSet(:, CurPatchIndx) + CurArray;
        NewWeight(:, CurPatchIndx) = NewWeight(:, CurPatchIndx) + 1;
        
    end
end



Count     =  0;
ImgTemp     =  zeros(Hight, Width);
ImgWeight   =  zeros(Hight, Width);
for i  = 1:PatchSize
    for j  = 1:PatchSize
        Count    =  Count+1;
        ImgTemp(i:Hight-PatchSize+i,j:Width-PatchSize+j) =  ImgTemp(i:Hight-PatchSize+i,j:Width-PatchSize+j) + col2im(NewPatchSet(Count,:), [PatchSize PatchSize],[Hight Width], 'sliding');
        ImgWeight(i:Hight-PatchSize+i,j:Width-PatchSize+j) =  ImgWeight(i:Hight-PatchSize+i,j:Width-PatchSize+j) + col2im(NewWeight(Count,:), [PatchSize PatchSize],[Hight Width], 'sliding');
    end
end


ImgRec = ImgTemp./(ImgWeight+eps);


return;



