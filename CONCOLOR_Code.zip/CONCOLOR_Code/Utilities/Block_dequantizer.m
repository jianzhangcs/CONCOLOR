function a=Block_dequantizer(x,QTable)

% Jian Zhang

a=x.*QTable;