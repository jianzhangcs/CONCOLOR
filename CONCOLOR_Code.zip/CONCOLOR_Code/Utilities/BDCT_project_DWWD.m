function projectedImage  = BDCT_project_DWWD(I_hat, QTable, blockSize)

% Jian Zhang

Q = QTable;
projectedCoe    = blkproc(I_hat, [blockSize blockSize], 'dct2');        % initial value is DCT coefficients of restored image

W = 1./(QTable.^2/(10000+eps));

fun = @(x) x.*W;

projectedCoe    = blkproc(projectedCoe, [blockSize blockSize], fun); 
projectedCoe    = blkproc(projectedCoe, [blockSize blockSize], fun); 

projectedImage = blkproc(projectedCoe, [blockSize blockSize], 'idct2');


