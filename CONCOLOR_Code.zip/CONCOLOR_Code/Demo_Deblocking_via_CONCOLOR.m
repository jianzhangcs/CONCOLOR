%--------------------------------------------------------------------------
%   These MATLAB programs implement the image deblocking algorithm
%   using COnstrained Non-COnvex LOw-Rank (CONCOLOR) model as described in paper:
%
%     Title:  CONCOLOR: COnstrained Non-COnvex LOw-Rank Model for Image Deblocking
%     Author: Jian Zhang, Ruiqin Xiong, Chen Zhao, Yongbing Zhang, Siwei Ma, Wen Gao
%     Publication: IEEE Transactions on Image Processing, vol. 25, no. 3, pp. 1246-1259, Mar. 2016.
%
% -------------------------------------------------------------------------------------------------------
% The software implemented by MatLab 7.10.0(2010a) are included in this package.
%
% ------------------------------------------------------------------
% Requirements
% ------------------------------------------------------------------
% *) Matlab 7.10.0(2010a) or later with installed:
% ------------------------------------------------------------------
% Version 1.0
% Author: Jian Zhang
% Email:  jian.zhang@pku.edu.cn
% Last modified by November 1, 2016

%   For updated versions of CONCOLOR, Consult: http://idm.pku.edu.cn/staff/zhangjian/

clc;
close all
clear;
cur = cd;
addpath(genpath(cur));

for ImgNo = 1 % 1:9
    for JPEG_Quality = 10 % 5:5:10
        
        switch ImgNo
            case 1
                fn = 'Barbara256.tif';
            case 2
                fn = 'butterfly256.tif';
            case 3
                fn = 'cameraman.tif';
            case 4
                fn = 'Foreman.bmp';
            case 5
                fn = 'house.tif';
            case 6
                fn = 'Leaves256.tif';
            case 7
                fn = 'Lena512.tif';
            case 8
                fn = 'Parrots256.tif';
            case 9
                fn = 'Peppers.bmp';
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        par.I  =  double( imread( fn ) );
        %par.I = par.I(1:64,1:64);
        
        [W H] = size(par.I);
        
        
        JPEG_Name = 'My_test.jpg';
        
        imwrite(uint8(par.I),JPEG_Name,'Quality',JPEG_Quality);
        par.nim          =    double(imread(JPEG_Name));
        JPEG_info = imfinfo(JPEG_Name);
        bpp = JPEG_info.FileSize*8/(W*H);
        
        JPEG_Name_Com = strcat(fn,'_JPEG_Quality_',num2str(JPEG_Quality),'_Compressed_SSIM_',num2str(cal_ssim(par.nim, par.I, 0, 0)),...
            '_PSNR_',num2str(csnr( par.nim ,par.I,0,0)),'dB.png');
        
        imwrite(uint8(par.nim ),strcat('Results\',JPEG_Name_Com));
        
        JPEG_header_info = jpeg_read(JPEG_Name);
        
        par.QTable = JPEG_header_info.quant_tables{1};
        
        par.blockSize = 8;
        par.C_q  = blkproc(par.nim , [8 8], 'dct2');
        
        
        meanQuant=mean(mean(par.QTable(1:3,1:3)));
        par.nSig = 1.195.*meanQuant.^0.6394 + 0.9673;
        
        par.lamada = 0.2;
        par.IterNum = 20;
        par.Qfactor = 0.4;
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        disp('Invoke CONCOLOR for Image Deblocking');
        
        [d_im, All_PSNR]  =  CONCOLOR_Deblocking(par.nim, par);
        PSNR   =   csnr(d_im, par.I, 0, 0);
        SSIM = cal_ssim(d_im, par.I, 0, 0);
        
        Final_Name = strcat(fn,'_JPEG_Quality_',num2str(JPEG_Quality),'_CONCOLOR_SSIM_',num2str(SSIM),'_PSNR_',num2str(PSNR),'dB.png');
        imwrite(uint8(d_im),strcat('Results\',Final_Name));
        
    end
    
end








